#!/bin/bash
# Creado por Claude: 1) pasa los tests, 2) sube el código a main (Render despliega solo),
# (versión corta: solo tests + push)
cd "$(dirname "$0")"
SRC="$PWD"; mkdir -p logs; ST="$SRC/logs/claude_people.status"; exec > >(tee "$SRC/logs/claude_people.log") 2>&1
echo "START $(date)" > "$ST"
URL="https://scare-tv.onrender.com"

echo "== 1/4 tests"
make test || { echo "TESTS_FAIL" >> "$ST"; echo "Los tests fallan: no subo nada."; exit 1; }
echo "TESTS_OK" >> "$ST"

echo "== 2/4 push a main"
TMP="$(mktemp -d)"
git clone -q https://github.com/antoniahp/scare-tv.git "$TMP/repo" || { echo "PUSH_FAIL clone" >> "$ST"; exit 1; }
rsync -a --exclude-from="$SRC/.gitignore" --exclude .git --exclude _backup_claude --exclude _to_delete --exclude "*.command" "$SRC/" "$TMP/repo/"
cd "$TMP/repo"
git add -A
git status --short
git -c user.name="$(git config --global user.name || echo antoniahp)" -c user.email="$(git config --global user.email || echo antoniahp@users.noreply.github.com)" \
  commit -q -F - <<'MSG' || { echo "PUSH_FAIL commit" >> "$ST"; exit 3; }
One row per person with their jump level (TV and phone, in production)

- Arrival is now a person: scare count, highest jump level (0-10) and fled,
  recomputed from their scares (false alarms left out).
- Every scare stores its jump level (the polaroid's 0-10, 10 = ran out of frame)
  and the person it happened to; a phone visit is one person.
- The TV links each scare to whoever is in front of it and uploads that link.
- Migration 0002 backfills levels and people for the scares already stored.
- Admin: "People" list with the highest jump level, filterable by phone/TV.

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01Vc1ukugcgrkgusrmn4nbtl
MSG
git push -q origin HEAD:main || { echo "PUSH_FAIL push" >> "$ST"; exit 4; }
echo "PUSH_OK $(git rev-parse --short HEAD)" >> "$ST"
cd "$SRC"

echo "DONE" >> "$ST"
echo "Subido. Render despliega en unos minutos."
