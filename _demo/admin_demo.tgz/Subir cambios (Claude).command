#!/bin/bash
# Creado por Claude: sube a main de antoniahp/scare-tv tu copia local del escritorio (la API web con ranking
# + los sustos nuevos). Respeta .gitignore y no borra nada que solo exista en GitHub.
cd "$(dirname "$0")"
SRC="$PWD"; LOG="$SRC/logs/claude_push.log"; mkdir -p logs; exec > >(tee "$LOG") 2>&1
echo "START $(date)"
TMP="$(mktemp -d)"
git clone https://github.com/antoniahp/scare-tv.git "$TMP/repo" || { echo "PUSH_FAIL clone"; exit 1; }
rsync -a --exclude-from="$SRC/.gitignore" --exclude .git --exclude _backup_claude --exclude "*.command" "$SRC/" "$TMP/repo/"
cd "$TMP/repo"
git add -A
git status --short | head -80
git -c user.name="$(git config --global user.name || echo antoniahp)" -c user.email="$(git config --global user.email || echo antoniaherrera620@gmail.com)" \
  commit -q -m "Web mirror with anonymous ranking API on Render + scarier scares

- Django/DRF stats API and Render Blueprint (web service + PostgreSQL)
- Mirror: the hit lands when you blink, random wait before the possession
- Scare-TV 2: horror prompts v4

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01Vc1ukugcgrkgusrmn4nbtl" || { echo "PUSH_FAIL commit"; exit 3; }
git push origin HEAD:main && echo "PUSH_OK $(git rev-parse --short HEAD)" || echo "PUSH_FAIL push"
