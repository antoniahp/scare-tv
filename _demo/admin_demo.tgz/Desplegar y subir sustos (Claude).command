#!/bin/bash
# Creado por Claude: 1) pasa los tests, 2) sube el código a main (Render despliega solo),
# 3) espera a que producción tenga la API nueva y 4) sube los sustos de la tele a la base de datos de Render.
cd "$(dirname "$0")"
SRC="$PWD"; mkdir -p logs; ST="$SRC/logs/claude_deploy.status"; exec > >(tee "$SRC/logs/claude_deploy.log") 2>&1
echo "START $(date)" > "$ST"
URL="https://scare-tv.onrender.com"

echo "== 1/4 tests"
make test || { echo "TESTS_FAIL" >> "$ST"; echo "Los tests fallan: no subo nada."; exit 1; }
echo "TESTS_OK" >> "$ST"

echo "== 2/4 push a main"
TMP="$(mktemp -d)"
git clone -q https://github.com/antoniahp/scare-tv.git "$TMP/repo" || { echo "PUSH_FAIL clone" >> "$ST"; exit 1; }
rsync -a --exclude-from="$SRC/.gitignore" --exclude .git --exclude _backup_claude --exclude _to_delete --exclude "*.command" "$SRC/" "$TMP/repo/"
cd "$TMP/repo"
git add -A
git status --short
git -c user.name="$(git config --global user.name || echo antoniahp)" -c user.email="$(git config --global user.email || echo antoniahp@users.noreply.github.com)" \
  commit -q -F - <<'MSG' || { echo "PUSH_FAIL commit" >> "$ST"; exit 3; }
Production night log: TVs upload to Render, Django admin at /admin

- /api/tv/nights|arrivals|scares: each TV mirrors its night log to production in the
  background (idempotent: records keep their local ids, so retries never duplicate).
- `make upload` (upload_nights) sends the nights already in the local database.
- Django admin at /admin to browse nights, arrivals and scares from TVs and phones;
  the superuser is created from DJANGO_SUPERUSER_* on Render (password set in the dashboard).
- render.yaml: collectstatic for the admin, createsuperuser on start.

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_01Vc1ukugcgrkgusrmn4nbtl
MSG
git push -q origin HEAD:main || { echo "PUSH_FAIL push" >> "$ST"; exit 4; }
echo "PUSH_OK $(git rev-parse --short HEAD)" >> "$ST"
cd "$SRC"

echo "== 3/4 esperando a que Render despliegue (hasta 20 min)…"
for i in $(seq 1 80); do
  code=$(curl -s -o /dev/null -w "%{http_code}" -m 60 "$URL/api/tv/nights")
  [ "$code" = "405" ] && break                 # GET → 405: the new endpoint exists (it only accepts POST)
  sleep 15
done
echo "endpoint: $code"
[ "$code" = "405" ] || { echo "DEPLOY_TIMEOUT $code" >> "$ST"; echo "Render aún no ha desplegado. Luego: make upload"; exit 5; }
echo "DEPLOY_OK" >> "$ST"

echo "== 4/4 subiendo los sustos de la tele a producción"
.venv/bin/python manage.py upload_nights --url "$URL" && echo "UPLOAD_OK" >> "$ST" || echo "UPLOAD_FAIL" >> "$ST"
echo "DONE" >> "$ST"
echo "Mira: $URL/admin/"
