#!/bin/bash
# Creado por Claude: genera las caras de terror nuevas (prompts v4) con SD-Turbo en este Mac y pasa los tests.
cd "$(dirname "$0")"
mkdir -p logs
echo "START $(date)" > logs/claude_run.status
make realistic 2>&1 | tee logs/claude_realistic.log
echo "REALISTIC_EXIT ${PIPESTATUS[0]} $(date)" >> logs/claude_run.status
make test 2>&1 | tee logs/claude_test.log
echo "TEST_EXIT ${PIPESTATUS[0]} $(date)" >> logs/claude_run.status
echo "DONE" >> logs/claude_run.status
